# متطلبات التنصيب #

#يوزر المطور
OWNER = ["Y_o_V"] 
OWNER__ID = 6094238403
OWNER_DEVELOPER = 6094238403
OWNER_NAME = "𓏺 َ𝗬𝗼𝘂𝘀𝗲𝗳"
#اسم التي سيظهر على صورة
infophoto = "Alsayed Playing"
DATABASE = "mongodb+srv://huSeen96:Huseenslah96@cluster0.ld2v7.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0" 
#قناة سورس
CHANNEL = "https://t.me/x_v_l"
#كروب سورس
GROUP = "https://t.me/PRTRZA"
#فيديو سورس اذا ماعندك خليه
VIDEO = "https://t.me/MusicxXxYousef/91"
#صورة سورس اذا ماعندك خليها
PHOTO = "https://t.me/MusicxXxYousef/90"
#ساوي كروب وضيف عليه مصنع ورفعو اشراف وحط يوزر الكروب هنا
LOGS = "xjjfjfhh"
 
 